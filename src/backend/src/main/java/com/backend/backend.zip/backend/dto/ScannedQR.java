package com.backend.backend.dto;

public class ScannedQR {

    private String scannedQRCode;
}
