package com.backend.backend.dto;

import lombok.Getter;

@Getter
public class BoardRequestsDto {
    
    
    private String title;
    private String contents;

    
}
