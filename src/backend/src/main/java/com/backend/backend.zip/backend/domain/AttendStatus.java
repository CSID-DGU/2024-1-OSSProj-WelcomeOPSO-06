package com.backend.backend.domain;

public enum AttendStatus {
    PRESENT,
    LATE,
   // EARLY_LEAVE,//조퇴
    ABSENCE, 
    PENDING
}
